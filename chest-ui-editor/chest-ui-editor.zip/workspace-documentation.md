# Minecraft Bedrock Chest UI Editor - Development Guide

This guide provides comprehensive documentation for developing and extending the Chest UI Editor, a web-based visual editor for creating custom chest UIs for Minecraft Bedrock Edition.

## Project Overview

### Purpose
A desktop-focused web application that allows users to:
- Visually design custom chest UIs using drag-and-drop components
- Preview designs in real-time
- Export designs as ready-to-use Minecraft Bedrock resource packs
- **Save/Load** - versioned project data in browser storage only
- **Import/Export ZIP** - resource packs and `chest_ui_data.json` for files and in-game use

### Target Platform
- **Primary:** Desktop (PC/Mac) - mouse/keyboard
- **Secondary:** Mobile (`mobile.js`, `mobile.css`) - touch placement, properties drawer, preview; test coarse-pointer layouts when changing editor UI

### Core Workflow
1. User drags components from palette onto 162x54px canvas (representing 9x3 chest grid)
2. Components are positioned and configured via properties panel
3. Live preview shows how UI will appear in-game
4. Export generates complete JSON UI file + resource pack ZIP

### In-Game Integration
- Generated UI triggers when player opens chest named `Display Name` (special formatting codes)
- Uses `container_items` collection binding
- Requires custom entity with matching inventory size OR use vanilla containers
- UI behavior controlled via Script API

## Architecture

### File Structure

```
chest-ui-editor/
├── index.html              # Main application HTML structure
├── README.md               # User-facing documentation
├── scripts/
│   ├── app.js              # Init, chestUiManager, Save/Load (browser), settings
│   ├── components.js       # Component type definitions & factory
│   ├── editor.js           # Canvas, selection, tabs (setActiveTab, tab_parent_id)
│   ├── export.js           # ZIP export & Import ZIP
│   ├── imageManager.js     # Image upload & management system
│   ├── mobile.js           # Mobile view handling
│   ├── preview.js          # Live preview & JSON UI generation
│   ├── project-format.js   # formatVersion 2 - build/validate/apply/persist
│   ├── properties.js       # Properties panel management
│   ├── templates.js        # Pre-built template definitions
│   └── util.js             # Utility functions (localStorage, ZIP helpers)
├── styles/
│   ├── main.css            # Core application styles
│   ├── components.css      # Component visual styles
│   ├── preview.css         # Preview area styles
│   └── mobile.css          # Mobile-specific styles (secondary)
└── assets/
    └── images/             # Texture files and UI assets
```

### Module Responsibilities

**app.js:**
- DOMContentLoaded initialization
- `chestUiManager` - multiple Chest UIs per project (`uis`, `activeId`, per-UI settings/components)
- Action buttons: New, **Save** / **Load** (browser only via `projectFormat`), Import ZIP, Export
- Settings modal; panel fold/unfold state
- Startup: `loadSavedProject({ silent: true })` when a valid v2 browser save exists

**project-format.js:**
- `FORMAT_VERSION: 2`, `FORMAT_LABEL: '2.0.0'`
- `build()` / `buildFromEditor()` - payload for browser save and ZIP `chest_ui_data.json`
- `validate()` / `assertValid()` - reject missing or legacy formats (including old `version: "1.1.0"` without `formatVersion: 2`)
- `apply()` - restore components, `uiProject`, settings, `uploadedImages` into editor
- `persistLocal()` / `saveToBrowser()` - write to `minecraft_chest_ui_project` in localStorage
- **Do not** add file download/upload to Save/Load; files are Import ZIP / Export ZIP only

**components.js:**
- Defines `componentTypes` object with all component definitions
- Component factory function `createComponent()`
- Auto-increment collection index system via `getNextCollectionIndex()`
- Rendering logic (editor view vs preview view)
- JSON generation per component type

**editor.js:**
- Canvas drag-and-drop system
- Component selection and manipulation
- Position snapping and constraints
- Z-index management
- Component CRUD operations
- **Tabs:** `setActiveTab()`, `tab_parent_id` on children, visibility filter for inactive tab pages in editor

**export.js:**
- Resource pack ZIP generation using JSZip library
- Texture path extraction from JSON UI
- User-uploaded image handling
- Placeholder texture generation for missing assets
- Manifest.json generation
- Path remapping (user_uploaded: → textures/ui/custom/)

**preview.js:**
- Generates complete JSON UI from component list
- Adds component-specific element definitions to JSON
- Image template system for conditional rendering
- Zoom controls for preview canvas

**imageManager:**
- Stores uploaded images in memory (Base64)
- Generates unique image names with timestamps
- Handles path translation between editor and export
- Prefix system: `user_uploaded:` for in-editor, `textures/ui/custom/` for export

## Component System

### Component Architecture

Each component type is defined in `componentTypes` object with:
- `name` - Display name
- `defaultWidth`, `defaultHeight` - Default dimensions in pixels
- `defaultProps` - Default property values
- `template` - HTML template selector for properties panel
- `render(component)` - Renders component in editor canvas
- `renderPreview(component)` - Renders component in preview
- `generateJSON(component)` - Exports component data

### Component Data Structure

```javascript
{
  id: "unique_id_1234",           // Generated by util.generateUniqueId()
  type: "container_item",          // Component type key
  x: 7,                            // X position in pixels from top-left
  y: 9,                            // Y position in pixels from top-left
  width: 18,                       // Width in pixels
  height: 18,                      // Height in pixels
  properties: {                    // Type-specific properties
    collection_index: 0,
    // ... other properties
  }
}
```

### 1. Container Item

**Purpose:** Standard interactive inventory slot for items

**Editor Properties:**
- `collection_index` - Slot number in container_items collection (auto-incremented)
- `slot_background_texture`, `slot_selected_texture`, `slot_highlight_texture` - Optional per-slot cell art (vanilla `inventory_*` defaults or custom paths)
- `x, y` - Position
- `width, height` - Size (default: 18x18)

**JSON UI Output:**
```json
{
  "item0@chest.container_item": {
    "collection_index": 0,
    "anchor_from": "top_left",
    "anchor_to": "top_left",
    "offset": [7, 9]
  }
}
```

**Generated Element Definition:**
Uses `@common.container_item` inheritance pattern with:
- Full item rendering (item_renderer)
- Stack count label
- Durability/storage bars
- Button interactions for take/place/drop
- Cell image background
- Lock overlay support

**Use Cases:**
- Standard chest slots
- Input/output slots for custom machines
- Inventory grids

### 2. Container Item with Picture

**Purpose:** Interactive slot with custom background image overlay

**Editor Properties:**
- `collection_index` - Slot number
- `picture` - Texture path (e.g., "textures/ui/book_ui")
- `x, y` - Position
- `width, height` - Size (default: 18x18)

**JSON UI Output:**
```json
{
  "item0@chest.container_item_with_picture": {
    "collection_index": 0,
    "anchor_from": "top_left",
    "anchor_to": "top_left",
    "offset": [7, 9],
    "$path_to_image": "textures/ui/book_ui"
  }
}
```

**Generated Element Definition:**
Based on container_item but adds:
- Custom background image layer (layer: 6)
- Image rendered at center behind item
- All standard container_item features

**Use Cases:**
- Specialized slots (e.g., book slot with book icon background)
- Filtered input slots (visual indication of accepted items)
- Crafting recipe hints

### 3. Progress Bar

**Purpose:** Visual indicator controlled by item name (0-9)

**Editor Properties:**
- `collection_index` - Slot number (use unobtainable item recommended)
- `value` - Preview value 0-9 (for editor display only)
- `x, y` - Position
- `width, height` - Size (default: 22x15)

**Control Mechanism:**
Item name's last character (after removing first 6 chars) determines progress:
- Rename item to end with "0" = empty bar
- Rename item to end with "5" = half full
- Rename item to end with "9" = full bar

**JSON UI Output:**
Generates 11 image layers with conditional visibility:
```json
{
  "item7@chest.progress_bar": {
    "collection_index": 7,
    "offset": [90, 16],
    "controls": [
      {
        "default": {
          "type": "image",
          "texture": "textures/ui/progress_bar/progress_bar",
          "size": ["100%", "100%"]
        }
      },
      {
        "progress1@image_template": {
          "$texture": "textures/ui/progress_bar/progress_bar0",
          "$binding_text": 0,
          "layer": 3
        }
      },
      // ... progress_bar1 through progress_bar9
    ]
  }
}
```

**Binding Logic via image_template:**
```json
{
  "binding_type": "view",
  "source_property_name": "( #hover_text - ('%.6s' * #hover_text) = $binding_text)",
  "target_property_name": "#visible"
}
```

Explanation:
- `#hover_text` - Item name
- `('%.6s' * #hover_text)` - First 6 characters
- `#hover_text - ('%.6s' * #hover_text)` - Removes first 6 chars
- `= $binding_text` - Compares result to binding_text value (0-9)

**Use Cases:**
- Furnace/smoker cooking progress
- Custom machine processing timers
- Crafting progress indicators

### 4. On/Off Item

**Purpose:** Toggle switch controlled by item name

**Editor Properties:**
- `collection_index` - Slot number
- `active` - Preview state (for editor display only)
- `x, y` - Position
- `width, height` - Size (default: 16x14)

**Control Mechanism:**
- Item name ends with "1" (after first 6 chars) = ON state
- Any other value = OFF state

**JSON UI Output:**
```json
{
  "item6@chest.on_off_item": {
    "collection_index": 6,
    "offset": [48, 45],
    "controls": [
      {
        "default": {
          "type": "image",
          "texture": "textures/ui/on_off/on_off",
          "size": ["100%", "100%"]
        }
      },
      {
        "on_off_active@image_template": {
          "$texture": "textures/ui/on_off/on_off_active",
          "$binding_text": 1,
          "layer": 3
        }
      }
    ]
  }
}
```

**Use Cases:**
- Power on/off switches
- Mode toggles
- Feature enable/disable indicators

### 5. Uninteractable Slot (pot)

**Purpose:** Visual-only slot with custom texture, items visible but not directly interactable

**Editor Properties:**
- `collection_index` - Slot number
- `texture` - Background texture path (default: "textures/ui/pot/pot")
- `x, y` - Position
- `width, height` - Size (default: 26x30)

**JSON UI Output:**
```json
{
  "item8@chest.pot": {
    "collection_index": 8,
    "offset": [120, 8],
    "$texture": "textures/ui/pot/pot"
  }
}
```

**Generated Element Definition:**
- Custom background image at layer 0
- Item renderer still shown (layer 7) but positioned with offset
- Stack count shown
- No durability/storage bars
- Standard button interactions maintained

**Use Cases:**
- Decorative slots with custom shapes
- Display slots in custom machines
- Result preview slots

**Best Practice:**
Rename items in this slot to random values to prevent shift-click auto-placement

### 6. Container Type

**Purpose:** Slot with dynamic background that changes based on item name (0-9)

**Editor Properties:**
- `collection_index` - Slot number
- `container_type` - Preview type 0-9 (for editor display)
- `x, y` - Position
- `width, height` - Size (default: 18x18)

**Control Mechanism:**
Item name ending (after first 6 chars) determines background:
- "0" = container_type0 texture
- "1" = container_type1 texture
- ... up to "9"

**JSON UI Output:**
Generates 10 conditional image layers:
```json
{
  "item9@chest.container_type": {
    "collection_index": 9,
    "offset": [90, 45],
    "controls": [
      {
        "container_type0@image_template": {
          "$texture": "textures/ui/container_type/container_type0",
          "$binding_text": 0,
          "layer": 8
        }
      },
      // ... container_type1 through container_type9
    ]
  }
}
```

**Use Cases:**
- Upgrade tier indicators
- Fuel type slots (coal/lava/etc show different backgrounds)
- Recipe variant slots

### 7. Image

**Purpose:** Static decorative image element

**Editor Properties:**
- `texture` - Texture path (can be user-uploaded)
- `alpha` - Transparency (0.0 to 1.0)
- `x, y` - Position
- `width, height` - Size (default: 32x32)

**JSON UI Output:**
```json
{
  "image_0": {
    "type": "image",
    "texture": "textures/ui/altar_cross",
    "layer": 2,
    "alpha": 1.0,
    "anchor_from": "top_left",
    "anchor_to": "top_left",
    "offset": [10, 10],
    "size": [32, 32]
  }
}
```

**Image Upload System:**
- User uploads → stored as Base64 in `imageManager.uploadedImages`
- Path format in editor: `user_uploaded:custom_imagename_uniqueid`
- On export: converted to `textures/ui/custom/custom_imagename_uniqueid.png`
- Included in resource pack ZIP

**Use Cases:**
- Decorative backgrounds
- UI borders and frames
- Custom icons and symbols

### 8. Button

**Purpose:** Non-slot action control bound to an existing `container_items` index via `property_bag`

**Editor Properties:**
- `target_collection_index` - slot to act on (does not consume its own `collection_index`)
- `pressed_button_name` - e.g. `button.container_auto_place`, `button.drop_all`
- `default_texture`, `hover_texture`, `pressed_texture` - borderless button textures (often skipped in ZIP via `defaultButtonTextures`)
- Optional embedded label/image (`show_label`, `label_text`, …)

**Export:** Inherits `drop_button@common.button` (or pack namespace equivalent); instance sets `$pressed_button_name` and texture variables.

**See also:** `how_to_add_new_component.md` §11 for full export shape.

### 9. Tab

**Purpose:** One tab toggle + one full-size page panel per dragged Tab component (add tabs incrementally; not a bundled multi-tab panel)

**Editor Properties:**
- `toggle_index` - drives exported `$name` (`toggle1`, `toggle2`, …) and page visibility bindings
- `toggle_group_name` - shared toggle group (default `custom_chest_tabs`)
- `is_active` - which tab is edited in the canvas (editor only; export uses bindings)
- Textures: same borderless set as Button - unselected `button_borderless_light`, selected `button_borderless_lightpressednohover`, hover-unselected `button_borderless_lighthover`
- Optional embedded label (same pattern as Button; default `show_label: false`, empty `label_text`)

**Child components:** Dropped while a tab is active get `tab_parent_id` = that tab’s `id`. `editor.setActiveTab(tabId)` switches visible children.

**Export (`preview.createTabsLayout()`):**
- Tab bar: `tab_toggle` controls with `$name: toggleN`, `common_toggles.light_text_toggle` pattern
- Each page: `panel` at `100%` × `100%` with `#visible` binding to `source_control_name: toggleN` (short names, not `tab_component_*` ids)
- Page children exported via `createNestedComponentControl()`
- Tabs disable `usesCollectionHost` shortcut only for `dynamic_grid`, not for `tab`

**Editor rendering:** `<motion.div class="editor-component button tab">` (not `<button>`) to avoid global `button { border-radius }` in `main.css`. Mouse handlers must use string concatenation for `classList`, not template literals evaluated at render time.

**Palette icon:** `assets/images/tab.png`

### 10. Dynamic Grid (scroll panel)

**Purpose:** Scrollable grid of slots using `grid` + scrollbar controls in exported JSON (not a single `collection_panel` slot list)

**Editor Properties:**
- `slot_width`, `slot_height` - cell size (default 18×18)
- `content_height` - scrollable content height in export
- `preview_slots` - how many slots to draw in the editor preview (not exported as slot count)
- `scroll_size_width` - scrollbar rail width
- `scroll_indent_image_texture`, `scrollbar_box_image_texture`, `scroll_background_image_texture` - rail, handle, background (`user_uploaded:` supported)
- `show_background` - toggle scroll panel background image
- `slot_background_texture`, `slot_selected_texture`, `slot_highlight_texture` - per-cell slot art (shared with container item defaults)

**Editor:** Fake scrollbar preview; column count derived from width minus scrollbar width.

**Export:** Dedicated branch in `preview.js`; textures extracted in `export.js` / `extractTexturesFromComponents()`

### 11. Label

**Purpose:** Static text display

**Editor Properties:**
- `text` - Text content
- `color` - RGB array [R, G, B] (0.0 to 1.0 scale)
- `font_scale_factor` - Label scale (editor uses `10 * font_scale_factor` px)
- `x, y` - Position

**JSON UI Output:**
```json
{
  "name": {
    "type": "label",
    "text": "Label Text",
    "color": [1.0, 1.0, 1.0],
    "anchor_from": "top_left",
    "anchor_to": "top_left",
    "offset": [23, -9]
  }
}
```

**Use Cases:**
- UI titles
- Instructions
- Section labels

### 12. Close Button

**Purpose:** Dismisses the chest screen using vanilla `common.close_button` behavior

**Editor Properties:**
- `default_texture`, `hover_texture`, `pressed_texture` (vanilla `textures/ui/close_button_*` or uploaded)
- Position and size

**Export:** `close_button_holder` stack panel with `close@common.close_button` and per-state `$close_button_texture` overrides.

**Settings integration:** `showCloseButton` in Chest UI settings can add a close control without placing this component; the draggable component is for custom position/textures.

**Use Cases:**
- Top-right dismiss control on custom chest panels
- Replacing default close placement from settings

## JSON UI Generation System

### Generation Flow

1. **Component Collection** (`preview.generateJSON()`)
   - Iterates through all editor components
   - Converts each to JSON UI control structure

2. **Screen Structure** (Fixed template)
   ```json
   {
     "namespace": "chest",
     "small_chest_screen@common.inventory_screen_common": {
       "variables": [
         {
           "requires": "($text = 'Display Name')",
           "$screen_content": "chest.custom"
         }
       ]
     },
     "custom": { /* main panel structure */ },
     "small_chest_custom_panel_top_half": { /* top section */ },
     "small_chest_custom_panel": { /* collection panel with components */ }
   }
   ```

3. **Component Definitions** (`addComponentDefinitions()`)
   - Adds element type definitions based on which component types are used
   - Only includes definitions for components actually in the design
   - Example: If design has progress_bar → adds `"progress_bar": {...}` definition

4. **Image Template System**
   ```json
   {
     "image_template": {
       "type": "image",
       "texture": "$texture",
       "bindings": [
         {
           "binding_name": "#hover_text",
           "binding_type": "collection",
           "binding_collection_name": "container_items"
         },
         {
           "binding_type": "view",
           "source_property_name": "( #hover_text - ('%.6s' * #hover_text) = $binding_text)",
           "target_property_name": "#visible"
         }
       ]
     }
   }
   ```

   Used by: progress_bar, on_off_item, container_type for conditional visibility

### Collection Panel Pattern

All interactive components (container_item variants) are placed in:
```json
{
  "small_chest_custom_panel": {
    "type": "collection_panel",
    "size": [162, 54],
    "$item_collection_name": "container_items",
    "collection_name": "container_items",
    "controls": [
      // All components added here as individual controls
    ]
  }
}
```

**Why collection_panel?**
- Binds entire panel to `container_items` collection
- Each child control can access collection via `collection_index`
- Enables per-slot data binding (#hover_text, #item_id_aux, etc.)

### Canvas Coordinate System

- **Canvas Size:** 162x54 pixels (matches vanilla small chest)
- **Origin:** Top-left (0, 0)
- **Standard Grid:** 9 columns × 3 rows
- **Standard Slot:** 18x18 pixels
- **Standard Spacing:** 18px between slot origins
- **Vanilla Layout:**
  - Row 0: Y=9, Columns 0-8: X=7,25,43,61,79,97,115,133,151
  - Row 1: Y=27
  - Row 2: Y=45

### Component Naming Convention

**Format:** `item{collection_index}@chest.{component_type}`

Examples:
- `item0@chest.container_item`
- `item5@chest.progress_bar`
- `item8@chest.pot`

**Special Cases:**
- Images: `image_{index}` (no @ syntax, direct definition)
- Labels: `name` (single static name, no indexing)

## Image Management System

### Upload Flow

1. User selects image file
2. `imageManager.storeImage()` reads file as Base64 Data URL
3. Generates unique name: `custom_{sanitized_filename}_{timestamp}_{random}`
4. Stores in memory: `imageManager.uploadedImages[path]`

### Path Format

**In Editor:**
```
user_uploaded:custom_myimage_abc123xyz
```

**In Export:**
```
textures/ui/custom/custom_myimage_abc123xyz
```

### Export Process

1. Extract all texture paths from JSON UI
2. For each `user_uploaded:` path:
   - Convert Base64 to binary blob
   - Add to ZIP: `textures/ui/custom/{imagename}.png`
   - Update JSON UI path to `textures/ui/custom/{imagename}`
3. For vanilla texture paths:
   - Try to fetch from `../assets/images/`
   - If missing, generate procedural placeholder (colored grid with filename)

### Placeholder Texture Generation

When texture not found:
- Creates 64x64 canvas
- Fills with color based on filename hash (consistent color per name)
- Draws 8px grid
- Renders filename text
- Purpose: Prevents broken resource pack, easy to identify missing assets

## Project Persistence

### Versioned format (`scripts/project-format.js`)

**Current:** `formatVersion: 2`, `formatLabel: "2.0.0"`. Bump `FORMAT_VERSION` for breaking schema changes; add migration in `validate()` if needed.

**Save / Load (browser only):**
- Key: `minecraft_chest_ui_project`
- **Save** → `projectFormat.saveToBrowser()` (`buildFromEditor` + `persistLocal`)
- **Load** → `projectFormat.apply()` after `validate()`; manual Load shows errors; startup load uses `{ silent: true }`
- **No** `.json` file download or file picker on Save/Load

**Legacy projects** without `formatVersion: 2` (including `version: "1.1.0"`) are **rejected** with a clear message. Users must re-save or re-export.

### Browser save payload shape

```javascript
{
  formatVersion: 2,
  formatLabel: "2.0.0",
  exportedAt: 1730000000000,
  components: [ /* flat list for active UI fallback */ ],
  uiProject: {
    activeId: "...",
    uis: [
      {
        id: "...",
        triggerTitle: "§F§l...",
        newTitle: "Display Name",
        settings: { mainPanelHeight, titleOffsetX, dialogBackground, showCloseButton, ... },
        components: [ /* per-UI component arrays */ ]
      }
    ]
  },
  settings: { /* global/settings modal snapshot */ },
  uploadedImages: {
    "user_uploaded:custom_image_abc": { data: "data:image/png;base64,...", ... }
  }
}
```

Settings-only updates and Import ZIP also call `projectFormat.persistLocal(projectFormat.buildFromEditor())` so the browser copy stays on v2.

### ZIP Import/Export (files)

**Export Structure:**
```
ChestUI_ResourcePack.zip
├── manifest.json                    # Resource pack manifest
├── ui/
│   └── chest_screen.json            # Generated JSON UI
├── textures/ui/
│   ├── custom/                      # User-uploaded images
│   │   └── custom_image_abc.png
│   ├── progress_bar/                # Component textures
│   │   ├── progress_bar.png
│   │   ├── progress_bar0.png
│   │   └── ... (progress_bar1-9)
│   ├── on_off/
│   │   ├── on_off.png
│   │   └── on_off_active.png
│   └── pot/
│       └── pot.png
└── chest_ui_data.json               # Same v2 project payload as browser save (formatVersion: 2)
```

**Import Process:**
1. User selects ZIP file (`import-zip` / `util.importZipFile`)
2. Parse `chest_ui_data.json` → `projectFormat.assertValid(data)`
3. Extract custom images from `textures/ui/custom/` (or `images/`) into `imageManager`
4. `projectFormat.apply(data)` then `persistLocal(buildFromEditor())` for browser continuity

**Export Process:**
- `export.js` embeds `projectFormat.build({ components, uiProject, settings })` in ZIP
- UI JSON files generated by `preview.generateProjectJSON()`

## Development Guidelines

### Adding New Component Types

1. **Define in componentTypes object (components.js):**
```javascript
my_new_component: {
  name: 'My Component',
  defaultWidth: 20,
  defaultHeight: 20,
  defaultProps: {
    collection_index: 0,
    myProperty: 'default_value'
  },
  template: '#my-component-properties',
  render: (component) => {
    return `<div class="editor-component my-component" ...></div>`;
  },
  renderPreview: (component) => {
    return `<div class="preview-component my-component" ...></div>`;
  },
  generateJSON: (component) => {
    return {
      type: "my_new_component",
      collection_index: component.properties.collection_index,
      myProperty: component.properties.myProperty,
      x: component.x,
      y: component.y,
      width: component.width,
      height: component.height
    };
  }
}
```

2. **Add HTML template in index.html:**
```html
<template id="my-component-properties">
  <div class="property-group">
    <label>My Property:</label>
    <input type="text" data-property="myProperty">
  </div>
</template>
```

3. **Add to component palette (index.html):**
```html
<div class="component-item" data-type="my_new_component" draggable="true">
  <div class="component-icon my-new-component"></div>
  <span>My Component</span>
</div>
```

4. **Add CSS styles (components.css):**
```css
.component-icon.my-new-component {
  background: /* visual representation */;
}

.editor-component.my-new-component,
.preview-component.my-new-component {
  /* rendering styles */
}
```

5. **Add JSON UI generation logic (preview.js):**

In `generateJSON()` controls loop:
```javascript
else if (component.type === 'my_new_component') {
  const index = Number(component.properties.collection_index);
  const controlName = `item${index}@chest.my_new_component`;
  
  controls.push({
    [controlName]: {
      "collection_index": index,
      "offset": [component.x, component.y],
      // ... component-specific properties
    }
  });
}
```

In `addComponentDefinitions()`:
```javascript
if (components.some(c => c.type === 'my_new_component')) {
  json.my_new_component = {
    // Element definition that components inherit from
  };
}
```

6. **Update collection index handling if needed:**

Add to `needsIndex` array in `createComponent()` if component uses collection binding:
```javascript
const needsIndex = ['container_item', 'container_item_with_picture', 
                    'progress_bar', 'on_off_item', 'pot', 'container_type',
                    'my_new_component'];
```

### Code Style Guidelines

**JavaScript:**
- Use ES6 features (const, let, arrow functions, template literals)
- Module pattern: objects with methods (not classes)
- Avoid jQuery - use vanilla JavaScript
- Functions should be pure when possible
- Use descriptive variable names

**Component Rendering:**
- Always include data attributes for component identification
- Use inline styles for dynamic properties (position, size, color)
- Use CSS classes for static styling
- Keep editor and preview rendering separate but consistent
- UI textures in editor/preview: use `image-rendering: pixelated` via `withPixelatedRendering()` / `styles/components.css` where applicable
- Prefer `<motion.div class="editor-component …">` over `<button>` for custom controls (tabs, buttons) to avoid global button styles in `main.css`

**JSON UI Generation:**
- Follow vanilla Minecraft JSON UI patterns exactly
- Use `@common.` inheritance where applicable
- Always include anchor_from/anchor_to for positioned elements
- Use variable system ($) for overridable properties
- Keep layer values consistent (avoid layer conflicts)

**Error Handling:**
- Console.error for development debugging
- Alert for user-facing errors
- Graceful degradation (missing textures → placeholders)
- Validate user input before processing

### Testing Checklist

When adding features:

- [ ] Test component drag-and-drop from palette
- [ ] Test component selection and property editing
- [ ] Test component positioning and sizing
- [ ] Test preview rendering matches editor
- [ ] Test JSON UI export structure
- [ ] Test resource pack ZIP contents
- [ ] Test re-import of exported ZIP
- [ ] Test save/load to localStorage
- [ ] Test with missing/invalid textures
- [ ] Test in actual Minecraft (create test entity/chest)

### JSON UI Validation

**Common Issues:**
1. **Missing texture paths** - Export includes placeholders
2. **Invalid collection_index** - Must be sequential from 0
3. **Wrong anchor points** - Always use top_left for positioned components
4. **Layer conflicts** - Keep consistent layer hierarchy
5. **Binding syntax errors** - Test Molang expressions carefully

**Reference Files:**
- `chest_screen.json` - Vanilla chest structure
- `ui_common.json` - Common element definitions
- `inventory_screen.json` - Container item patterns

## Key Patterns and Conventions

### Conditional Image Rendering via Bindings

The editor extensively uses item name substring matching for dynamic UIs:

```json
{
  "binding_name": "#hover_text",
  "binding_type": "collection",
  "binding_collection_name": "container_items"
},
{
  "binding_type": "view",
  "source_property_name": "( #hover_text - ('%.6s' * #hover_text) = $binding_text)",
  "target_property_name": "#visible"
}
```

**How it works:**
- `#hover_text` gets item's display name
- `'%.6s' * #hover_text` extracts first 6 characters
- Subtraction removes those 6 characters, leaving remainder
- Compares remainder to `$binding_text` (passed as variable)
- Result determines visibility

**Why remove 6 characters?**
Allows prefix for organization while keeping control character:
- Example: "CRAFT0" → "0" extracted → matches $binding_text: 0
- Example: "ITEM_5" → "5" extracted → matches $binding_text: 5

### Variable Inheritance Pattern

Component definitions use heavily parametrized templates:

```json
{
  "container_item": {
    "$cell_image_size|default": [18, 18],
    "$item_renderer_size|default": [16, 16],
    // ... many overridable defaults
    
    "controls": [
      {
        "item_cell": {
          "size": "$cell_image_size"  // Uses overridden or default value
        }
      }
    ]
  }
}
```

When component instance inherits:
```json
{
  "item0@chest.container_item": {
    "$cell_image_size": [20, 20],  // Override default
    "collection_index": 0
  }
}
```

### Collection Binding Scope

Components inside collection_panel automatically have collection binding context:

```json
{
  "collection_panel": {
    "collection_name": "container_items",
    "controls": [
      {
        "item0@chest.container_item": {
          "collection_index": 0,  // Binds to container_items[0]
          // All child bindings access this collection item
        }
      }
    ]
  }
}
```

### Layer Hierarchy (Z-ordering)

Standard layer values used:
- 0: Base panel/background
- 1-2: Background images, cell backgrounds
- 3-6: Cell overlays, locks, selection
- 7: Item renderer
- 8: Conditional overlays (container_type backgrounds)
- 10+: Special overlays (bundle, durability bars)
- 15+: Flying item renderer
- 20+: Storage/durability bars
- 27: Stack count labels

## Integration with Parent workspace-documentation

### JSON UI Fundamentals

For core JSON UI concepts, refer to parent `workspace-documentation.md`:
- Namespace system and element referencing
- Binding types (collection, view, global)
- Molang expression syntax
- Common vanilla elements (@common.*)
- Focus system and button mappings

### Chest Editor Specifics

This editor specializes in:
- Visual layout design (not hand-coding JSON)
- Component-based UI construction
- Collection panel pattern exclusively
- Item name-based state control
- Desktop-focused tooling

### Key Differences

**Parent workspace-documentation:** General JSON UI development
- Hand-editing JSON UI files
- Working in `resource_pack/ui/custom/` directory
- Full JSON UI feature set
- Mobile + desktop + console considerations

**Chest editor:** Visual UI builder
- Web-based drag-and-drop interface
- Generates JSON UI programmatically
- Subset of JSON UI focused on chest containers
- Desktop-first design approach

## Reference Documentation

### Primary References

**Vanilla JSON UI Files:**
- `../chest_screen.json` - Chest screen structure, grid layout
- `../ui_common.json` - Common elements (container_item, buttons, labels)
- `../inventory_screen.json` - Inventory patterns, container slots

**Online Documentation:**
- [JSON UI Introduction](https://wiki.bedrock.dev/json-ui/json-ui-intro)
- [JSON UI Documentation](https://wiki.bedrock.dev/json-ui/json-ui-documentation)
- [Best Practices](https://wiki.bedrock.dev/json-ui/best-practices)

### Code References

**Understanding Component System:**
- Read `scripts/components.js` - Component type definitions
- Read `scripts/preview.js` - JSON UI generation logic

**Understanding Export:**
- Read `scripts/export.js` - Resource pack creation
- Study template examples in `scripts/templates.js`

## Common Development Tasks

### Task: Add a New Template

**File:** `scripts/templates.js`

```javascript
templates: {
  my_custom_template: function() {
    const components = [];
    
    // Add label
    const label = createComponent('label', 50, -9);
    label.properties.text = "My Custom UI";
    label.properties.color = [0.3, 0.3, 0.3];
    components.push(label);
    
    // Add slots in pattern
    for (let i = 0; i < 5; i++) {
      const slot = createComponent('container_item', 30 + i * 20, 10);
      slot.properties.collection_index = i;
      components.push(slot);
    }
    
    return components;
  }
}
```

**Also add to HTML:**
```html
<div class="template-item" data-template="my_custom_template">
  <div class="template-preview"><!-- preview image --></div>
  <h4>My Custom Template</h4>
  <p>Description here</p>
</div>
```

### Task: Modify Export Structure

**File:** `scripts/export.js`

Common modifications:
- Change resource pack name/description in `generateManifestJson()`
- Add additional files to ZIP in `createResourcePackZip()`
- Modify texture path handling in `updateImagePath()`

### Task: Add Component Property

1. Update `componentTypes[type].defaultProps`
2. Add HTML input in template
3. Update `render()` and `renderPreview()` to use property
4. Update JSON generation in `preview.js` to include property

### Task: Modify Canvas Size

**Warning:** Changing canvas size affects all templates and vanilla compatibility

**Files to modify:**
- `preview.js` - Update `small_chest_custom_panel` size
- `styles/preview.css` - Update `.chest-panel` dimensions
- `scripts/editor.js` - Update canvas constraints

## Best Practices for This Editor

### 1. Maintain JSON UI Accuracy

- **Always** validate generated JSON UI against vanilla patterns
- Test exports in Minecraft before committing changes
- Use exact vanilla syntax for common elements
- Don't invent new binding patterns - use proven vanilla ones

### 2. Component Design Philosophy

- Components should map 1:1 to JSON UI control patterns
- Keep component types focused (single responsibility)
- Properties should directly map to JSON UI properties
- Avoid complex component composition (keep flat)

### 3. Performance Considerations

- Minimize re-renders of preview (debounce updates)
- Store images as Base64 (client-side only, no server)
- Use localStorage efficiently (don't save on every change)
- Lazy-load textures in preview

### 4. User Experience

- Provide visual feedback for all actions
- Use alerts sparingly (only for errors/confirmations)
- Auto-increment collection indices (don't make user manage)
- Snap to grid optional (some UIs need precise positioning)
- Save state on exit (prompt if unsaved changes)

### 5. Code Organization

- Keep module responsibilities clear and separated
- Use consistent naming (camelCase for JS, kebab-case for CSS)
- Comment complex binding logic
- Document any deviations from vanilla patterns

### 6. Error Prevention

- Validate collection indices are unique
- Prevent negative positions
- Constrain components to canvas bounds
- Check for missing textures before export
- Validate color arrays are [R,G,B] format

## Template System

### Built-in Templates

**vanilla:**
- 9x3 grid of container_items
- Standard chest layout
- Collection indices 0-26

**Cooking_Pot:**
- 3x2 input grid (indices 0-5)
- On/off switch (index 6)
- Progress bar (index 7)
- Pot slot (index 8, uninteractable)
- Container type slot (index 9)
- Output slot (index 10)

**crafting:**
- 3x3 crafting grid
- Similar to vanilla crafting table layout

### Template Design Guidelines

- Start collection indices at 0
- Increment sequentially
- Leave no gaps in indices
- Include appropriate labels
- Use appropriate component types for function
- Consider visual balance and spacing

## Known Limitations

### Editor Limitations

1. **Canvas Size:** Fixed at 162x54 (small chest size only)
2. **No Grid System:** Components use collection_panel, not grid element
3. **Single Screen:** Only generates small_chest_screen variant
4. **Collection Binding Only:** All interactive components bound to container_items
5. **No Dynamic Text:** Labels are static (no text bindings)
6. **No Nested Panels:** Flat component structure only

### JSON UI Limitations

1. **Item Name Control:** Progress/toggle/type rely on item renaming
   - Requires unobtainable items to prevent player interference
   - Limited to 10 states (0-9 character matching)

2. **No Hover Tooltips:** Custom tooltips not implemented

3. **Desktop Only:** Generated UI uses desktop_screen variable requirement

## Troubleshooting Guide

### Component Not Appearing in Export

**Check:**
- Is component in components array? (check editor.getComponents())
- Does component have valid collection_index?
- Is JSON generation logic in preview.js handling this type?
- Is element definition added in addComponentDefinitions()?

### Texture Not Loading

**Check:**
- Path format correct? (textures/ui/path not images/ui/path)
- Image uploaded properly? (check imageManager.uploadedImages)
- Path remapping working? (user_uploaded: → textures/ui/custom/)
- Texture file actually in ZIP? (check export.js texture extraction)

### Progress Bar/Toggle Not Working In-Game

**Check:**
- Item in slot is unobtainable (prevents shift-click placement)
- Item renamed correctly (last char after 6-char prefix)
- image_template binding logic present in JSON
- Texture files exist for all states (0-9)

### Import Failing

**Check:**
- ZIP contains `chest_ui_data.json`?
- `formatVersion === 2` (old exports without `formatVersion` are unsupported)
- `projectFormat.validate()` error message for missing `components` or wrong version
- Image paths in data match images in ZIP?
- No corrupted Base64 image data?

### Save/Load Failing

**Check:**
- Browser save exists under `minecraft_chest_ui_project`?
- Saved data has `formatVersion: 2` (re-save or Import ZIP after upgrading editor)
- Use **Import ZIP** / **Export** for file transfer, not Save/Load

## Advanced Techniques

### Custom Binding Patterns

While editor uses item name matching, developers can manually edit exported JSON to add:
- Collection length bindings
- Item ID conditionals
- Complex Molang expressions
- View bindings to other controls

**Workflow:**
1. Design layout in editor
2. Export resource pack
3. Manually edit chest_screen.json for advanced features
4. Re-package as resource pack

### Dynamic Slot Counts

To support variable slot counts:
1. Export base design with maximum slots
2. Edit JSON to add visibility bindings based on collection length
3. Use Script API to control actual collection size

### Multi-State Components

Beyond 0-9 states using first-char matching:
```json
{
  "source_property_name": "( ('%.1s' * #hover_text) = $binding_text)",
  "target_property_name": "#visible"
}
```
Extracts first character instead of character after 6th position.

## Future Enhancement Ideas

**Editor Features:**
- Undo/redo system
- Component grouping
- Alignment tools (align left, center, distribute)
- Grid snap toggle
- Ruler/guidelines
- Component duplication (Ctrl+D)
- Multi-select and bulk operations

**Component Types:**
- Scrolling panel component
- Custom renderer components
- Animation support
- Toggle group components

**Export Enhancements:**
- Large chest variant generation
- Behavior pack template (Script API boilerplate)
- Multiple screen variants (desktop/pocket)
- Custom namespace option

**Import Improvements:**
- Import from vanilla chest_screen.json
- Merge templates
- Component library system

## Technical Constraints

### Browser Requirements

- Modern browser with ES6 support
- localStorage enabled
- Canvas API support
- File API for image upload
- Blob/ZIP support (JSZip library)

### Resource Pack Requirements

- Minecraft Bedrock Edition 1.16.0+
- format_version: 2 in manifest
- Valid UUID generation for manifest

### Performance Targets

- Load time < 2 seconds
- Preview update < 100ms
- Export generation < 5 seconds (with images)
- Smooth drag interactions (60fps)

## Glossary

**Collection Index:** Numeric identifier for slot position in container_items array

**Container Items:** The collection binding name for chest/container inventory slots

**Image Template:** Reusable JSON UI element with variable bindings for conditional rendering

**Collection Panel:** JSON UI panel type that binds to an array of data, providing collection context to children

**Hover Text:** In-game item name accessible via #hover_text binding (used for control logic)

**Layer:** Z-index in JSON UI, controls rendering order (higher = on top)

**Anchor:** Positioning reference point, controls where element aligns to parent and where element's position originates

**User Uploaded Image:** Custom image uploaded by user, stored as Base64 during editing, exported to textures/ui/custom/

**Placeholder Texture:** Procedurally generated texture for missing assets (colored grid with filename)

## Additional Notes

### Why Collection Panel vs Grid?

Grid requires `grid_item_template` (all items use same template).
Collection panel allows each control to be unique, enabling:
- Different component types in same container
- Individual positioning per slot
- Mixed slot sizes
- Custom properties per slot

### Why Item Name Control?

Bedrock JSON UI has limited Script API integration for custom screens. Using item names for state:
- No special JSON UI bindings needed
- Works with vanilla container system
- Controllable via Script API (rename items programmatically)
- Visual feedback in inventory (can see state)

### Canvas Dimensions

162x54 matches vanilla small chest exactly:
- 9 slots × 18px = 162px width
- 3 rows × 18px = 54px height
- Maintains visual accuracy between editor and game

## Contributing Guidelines

When extending this editor:

1. **Research first** - Study how vanilla JSON UI implements similar features
2. **Test thoroughly** - Verify in actual Minecraft before committing
3. **Document clearly** - Update this guide with new patterns
4. **Maintain compatibility** - Don't break existing projects/exports
5. **Keep it simple** - Editor should be accessible to non-programmers

## Version History

- **2.0.0** (`formatVersion: 2`) - Current project format
  - Versioned browser save/load and ZIP `chest_ui_data.json`
  - Per-Tab components with `tab_parent_id` / `createTabsLayout`
  - Button, dynamic grid, multi-Chest-UI `chestUiManager`
  - Legacy `version: "1.1.0"` / unversioned saves not loaded
- **1.0.2** - Earlier editor (pre-`formatVersion`; not compatible with v2 load)

## Support and Resources

**For JSON UI Questions:**
- Refer to parent `workspace-documentation.md` in repository root
- Check vanilla JSON UI files in `resource_pack/ui/`
- Visit https://wiki.bedrock.dev/json-ui/

**For Editor Questions:**
- Read this guide thoroughly
- Examine existing component implementations
- Study template examples
- Test changes in isolation before integration


